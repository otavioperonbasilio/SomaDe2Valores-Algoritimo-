const Discord = require("discord.js");
const { ActionRowBuilder, TextInputBuilder, TextInputStyle, InteractionType, ModalBuilder, EmbedBuilder, ButtonBuilder } = require("discord.js");
const { configuracao } = require("../../DataBaseJson");
const { perms, General, emoji, produto, tema } = require("../../DataBaseJson")
const fs = require("fs");

module.exports = {
    name: 'interactionCreate',

    run: async (interaction, client) => {

        if (interaction.isButton()) {
            if (interaction.customId === 'solicit_estoque') {
                const modalaAA = new ModalBuilder()
                    .setCustomId('gostModalStock')
                    .setTitle(`Configurar anti fake`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('stock')
                    .setLabel('Produto?')
                    .setPlaceholder('Nome do produto')
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true)
                    .setMaxLength(100)

                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('stock2')
                    .setLabel('Estoque?')
                    .setPlaceholder('Quantos produtos?')
                    .setStyle(TextInputStyle.Paragraph)
                    .setRequired(true)
                    .setMaxLength(4)

                const newnameboteN3 = new TextInputBuilder()
                    .setCustomId('stock3')
                    .setLabel('Por que quer? ( OPCIONAL )')
                    .setPlaceholder('Motivo aqui')
                    .setStyle(TextInputStyle.Paragraph)
                    .setRequired(false)
                    .setMaxLength(300)

                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);
                const firstActionRow5 = new ActionRowBuilder().addComponents(newnameboteN3);


                modalaAA.addComponents(firstActionRow3, firstActionRow4, firstActionRow5);
                await interaction.showModal(modalaAA);
            }
        }

        if (interaction.type == InteractionType.ModalSubmit) {
            if (interaction.customId === 'gostModalStock') {
                const title = interaction.fields.getTextInputValue('stock');
                let title2 = interaction.fields.getTextInputValue('stock2');
                const title3 = interaction.fields.getTextInputValue('stock3');

                if (General.get("canais.logs_adm") == "") {

                    interaction.reply({ content: `${emoji.get(`alerta`)} | O canal de logs adm não está configurado ainda!`, ephemeral: true });
                    return;

                }
        
                if (isNaN(title2)) {
                    interaction.reply({ content: `${emoji.get(`alerta`)} | Por favor, insira apenas números para a quantidade.`, ephemeral: true });
                    return;
                }
                
                title2 = parseInt(title2);
        
                const channelLogsPriv = interaction.guild.channels.cache.get(General.get(`canais.logs_adm`));
                if (channelLogsPriv) {
                  await channelLogsPriv.send({
                    embeds: [new EmbedBuilder()
                      .setAuthor({ name: `${interaction.user.username}`, iconURL: interaction.user.avatarURL({ dynamic: true }) })
                      .setTitle(`${client.user.username} | Sugestão Restoque`)
                      .setFields(
                        {
                            name: `Produto`, value: `\`${title}\``, inline: true
                        },
                        {
                            name: `Quantia`, value: `\`${title2}\``, inline: true
                        },
                        {
                            name: `Motivo`, value: `\`${title3 != "" ? title3 : `\`Não justificado.\``}\``, inline: true
                        }
                      )
                      .setThumbnail(interaction.user.avatarURL({ dynamic: true }))
                      .setColor(`#00FFFF`)
                      .setFooter({ text: `${interaction.user.username} - ${interaction.user.id}`, iconURL: interaction.user.avatarURL({ dynamic: true }) })
                      .setTimestamp()
                    ], components: [
                        new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`slaprr`).setLabel(`Mensagem Automática`).setStyle(2).setDisabled(true)
                        )
                    ]
                  });
                };
        
                interaction.reply({ content: `${emoji.get(`certo`)} | Sugestão enviada com êxito.`, ephemeral: true });
            }
        }
        


    }
}