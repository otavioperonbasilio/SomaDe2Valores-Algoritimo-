const { ActivityType } = require('discord.js');
const axios = require('axios');
const { JsonDatabase } = require('wio.db');
const config = new JsonDatabase({ databasePath: "./config.json" });
const General = new JsonDatabase({ databasePath: "./DataBaseJson/config.json" });
const colors = require("colors")

module.exports = {
    name: 'ready',
    run: async (client) => {
        console.clear()
        console.log(`${colors.green("[START]")} ${client.user.tag} Foi iniciado.`)
        console.log(`${colors.green("[SIZE SERVERS]")} Atualmente em ${client.guilds.cache.size} servidores.`)
        console.log(`${colors.green("[SIZE MEMBERS]")} Contendo ${client.guilds.cache.reduce((a, b) => a + b.memberCount, 0)} usuarios.`)
        console.log(``)
        console.log(`${colors.cyan("[CREDITS]")} @gostbanido | @inbiza`)
        console.log(`${colors.cyan("[HELP LINK]")} https://discord.gg/uaWcBMDWck`)
        
        var position = 0;
        setInterval(() => {
            const statusTexto = General.get(`status.texto`);
            const statusAtividade = General.get(`status.atividade`)
            const statusPresenca = General.get(`status.presence`);
            const messages = [
              `${statusTexto}`,
            ]
            client.user.setPresence({
               activities: [{
                  name: `${messages[position++ % messages.length]}`,
                  type: ActivityType.statusAtividade
               }]
            })
            client.user.setStatus(statusPresenca)
        }, 4000);

        setarbio();

        setInterval(() => {
            setarbio();
        }, 300000);

        function setarbio() {
            axios.patch('https://discord.com/api/v10/applications/@me', {
                description: `**Fiel Store **\https://discord.gg/gsmK7VB9yK`,
            },
            {
                headers: {
                    Authorization: `Bot ${config.get(`token`)}`,
                    'Content-Type': 'application/json'
                }
            });
        }
    }
};
