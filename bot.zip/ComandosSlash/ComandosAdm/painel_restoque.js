const Discord = require("discord.js");
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, ChannelSelectMenuBuilder, RoleSelectMenuBuilder, ChannelType, UserSelectMenuBuilder, StringSelectMenuBuilder } = require("discord.js")
const { perms, General, emoji, produto, tema } = require("../../DataBaseJson")
const fs = require("fs");

module.exports = {
  name: "painel_restoque",
  description: "[🛠️|📦] Configurações do painel restoque",
  type: Discord.ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {
    if (!perms.has(interaction.user.id)) return interaction.reply({
      embeds: [new EmbedBuilder()
        .setDescription(`${emoji.get(`alerta`)} | Você não possui permissão para utilizar este comando!`)
        .setColor("Red")
      ],
      ephemeral: true 
    })

    const textoView = General.get("systemrestoque.texto_painel")
    const descView = General.get("systemrestoque.desc_painel")
    const miniaturaView = General.get("systemrestoque.miniatura")
    const bannerView = General.get("systemrestoque.banner")
    const footerView = General.get("systemrestoque.footer")
    const colorView = General.get("systemrestoque.color")

    const embed = new EmbedBuilder()
    .setAuthor({ name: interaction.client.user.username, iconURL: interaction.client.user.displayAvatarURL({ dynamic: true })})
    .setDescription(`\nTexto Atual: **${textoView!= "" ? textoView : "Não definido."}**\nDescrição Atual: **${descView != "" ? descView : "Não definido."}**\nMiniatura: **[Clique Aqui](${miniaturaView != "" ? miniaturaView : "Não definido."})**\nBanner: **[Clique Aqui](${bannerView!= "" ? bannerView : "Não definido."})**\nFooter: **${footerView != "" ? footerView : "Não definido."}**\nColor: **${colorView != "" ? colorView : "Não definido."}**\n\n**Você pode configurar o bot usando os botões abaixo:**`)
    .setThumbnail(`${client.user.displayAvatarURL()}`)
    .setColor("#00FFFF")
    .setFooter({ text: `${interaction.guild.name} - Todos os direitos reservados.`, iconURL: interaction.guild.iconURL()});

    const buttons = new Discord.ActionRowBuilder().addComponents(
      new Discord.ButtonBuilder()
      .setCustomId("config_texto_painel")
      .setEmoji(`${emoji.get(`fix`)}`)
      .setLabel("Texto Painel")
      .setStyle(1),
      new Discord.ButtonBuilder()
      .setCustomId("config_desc_painel")
      .setEmoji(`${emoji.get(`fix`)}`)
      .setLabel("Descrição Painel")
      .setStyle(1),
      new Discord.ButtonBuilder()
      .setCustomId("config_mini")
      .setEmoji(`${emoji.get(`fix`)}`)
      .setLabel("Miniatura")
      .setStyle(1),
      new Discord.ButtonBuilder()
      .setCustomId("config_banner")
      .setEmoji(`${emoji.get(`fix`)}`)
      .setLabel("Banner")
      .setStyle(1),
      new Discord.ButtonBuilder()
        .setCustomId("config_footer")
        .setEmoji(`${emoji.get(`fix`)}`)
        .setLabel("Footer")
        .setStyle(1)
    );

    const buttons2 = new Discord.ActionRowBuilder().addComponents(
      new Discord.ButtonBuilder()
        .setCustomId("config_color")
        .setEmoji(`${emoji.get(`fix`)}`)
        .setLabel("Color")
        .setStyle(2),
        new Discord.ButtonBuilder()
        .setCustomId("config_button")
        .setEmoji(`${emoji.get(`fix`)}`)
        .setLabel("Botão (em breve)")
        .setStyle(2)
        .setDisabled(true),
        new Discord.ButtonBuilder()
        .setURL("https://discord.gg/d2E8VxXPQK")
        .setEmoji(`👷`)
        .setLabel("Suporte")
        .setStyle(5)
    );

    interaction.reply({
      embeds: [embed],
      components: [buttons, buttons2],
      ephemeral: false,
    });

    client.on("interactionCreate", async (interaction) => {
      if (!interaction.isButton()) return;
      if (interaction.customId === "config_banner") {
        const modal = new ModalBuilder()
        .setCustomId('modalbanner')
        .setTitle('Alterar Banner')
        
        const text = new TextInputBuilder()
        .setCustomId('banner')
        .setLabel('Link do Banner:')
        .setPlaceholder('Link aqui')
        .setRequired(true)
        .setStyle(1)
        
        modal.addComponents(new ActionRowBuilder().addComponents(text))
        
        interaction.showModal(modal)
      }

      if (interaction.customId === "config_mini") {
        const modal = new ModalBuilder()
        .setCustomId('modalmini')
        .setTitle('Alterar Miniatura')
        
        const text = new TextInputBuilder()
        .setCustomId('mini')
        .setLabel('Link da Miniatura:')
        .setPlaceholder('Link aqui')
        .setRequired(true)
        .setStyle(1)
        
        modal.addComponents(new ActionRowBuilder().addComponents(text))
        
        interaction.showModal(modal)
      }

      if (interaction.customId === "config_footer") {
        const modal = new ModalBuilder()
        .setCustomId('modalfooter')
        .setTitle('Alterar Footer')
        
        const text = new TextInputBuilder()
        .setCustomId('footer')
        .setLabel('Footer:')
        .setPlaceholder('Escreva o que terá no footer da embed')
        .setRequired(true)
        .setStyle(1)
        
        modal.addComponents(new ActionRowBuilder().addComponents(text))
        
        interaction.showModal(modal)
      }

      
      if (interaction.customId === "config_texto_painel") {
        const modal = new ModalBuilder()
        .setCustomId('modaltext')
        .setTitle('Alterar Texto')
        
        const text = new TextInputBuilder()
        .setCustomId('text')
        .setLabel('Texto:')
        .setPlaceholder('Escreva o que terá no texto da embed')
        .setRequired(true)
        .setStyle(1)
        
        modal.addComponents(new ActionRowBuilder().addComponents(text))
        
        interaction.showModal(modal)
      }

      if (interaction.customId === "config_desc_painel") {
        const modal = new ModalBuilder()
        .setCustomId('modaldesc')
        .setTitle('Alterar Descrição')
        
        const desc = new TextInputBuilder()
        .setCustomId('desc')
        .setLabel('Descrição:')
        .setPlaceholder('Escreva o que terá na descrição da embed')
        .setRequired(true)
        .setStyle(1)
        
        modal.addComponents(new ActionRowBuilder().addComponents(desc))
        
        interaction.showModal(modal)
      }

      if (interaction.customId === "config_color") {
        const modal = new ModalBuilder()
        .setCustomId('modalcolor')
        .setTitle('Alterar Cor')
        
        const color = new TextInputBuilder()
        .setCustomId('color')
        .setLabel('Color:')
        .setPlaceholder('Coloque uma cor para sua embed aqui')
        .setRequired(true)
        .setStyle(1)
        
        modal.addComponents(new ActionRowBuilder().addComponents(color))
        
        interaction.showModal(modal)
      }

    });

     client.on("interactionCreate", async (interaction) => {
      
      function uppembed() {
        config = JSON.parse(fs.readFileSync('./config.json'));

        const textoView = General.get("systemrestoque.texto_painel")
        const descView = General.get("systemrestoque.desc_painel")
        const miniaturaView = General.get("systemrestoque.miniatura")
        const bannerView = General.get("systemrestoque.banner")
        const footerView = General.get("systemrestoque.footer")
        const colorView = General.get("systemrestoque.color")
    
        const embed2 = new EmbedBuilder()
        .setAuthor({ name: interaction.client.user.username, iconURL: interaction.client.user.displayAvatarURL({ dynamic: true })})
        .setDescription(`\nTexto Atual: **${textoView!= "" ? textoView : "Não definido."}**\nDescrição Atual: **${descView != "" ? descView : "Não definido."}**\nMiniatura: **[Clique Aqui](${miniaturaView != "" ? miniaturaView : "Não definido."})**\nBanner: **[Clique Aqui](${bannerView!= "" ? bannerView : "Não definido."})**\nFooter: **${footerView != "" ? footerView : "Não definido."}**\nColor: **${colorView != "" ? colorView : "Não definido."}**\n\n**Você pode configurar o bot usando os botões abaixo:**`)
        .setThumbnail(`${client.user.displayAvatarURL()}`)
        .setColor("#00FFFF")
        .setFooter({ text: `${interaction.guild.name} - Todos os direitos reservados.`, iconURL: interaction.guild.iconURL()});
         interaction.message.edit({ embeds: [embed2] })
      }


     if (interaction.customId === "modalbanner") {
      const banner = interaction.fields.getTextInputValue("banner")
      if (!link(banner)) return interaction.reply({ content: `❌ | Link do banner inválido!`, ephemeral: true })

      General.set(`systemrestoque.banner`, banner)

        interaction.reply({ content: `${emoji.get(`certo`)} | Banner do painel alterado!`, ephemeral: true })

        uppembed()

     }

     if (interaction.customId === "modalmini") {
      const mini = interaction.fields.getTextInputValue("mini")
      if (!link(mini)) return interaction.reply({ content: `❌ | Link da miniatura inválido!`, ephemeral: true })

      General.set(`systemrestoque.miniatura`, mini)

        interaction.reply({ content: `${emoji.get(`certo`)} | Miniatura do painel alterado!`, ephemeral: true })

        uppembed()

     }

     if (interaction.customId === "modalfooter") {
      const footer = interaction.fields.getTextInputValue("footer")

      General.set(`systemrestoque.footer`, footer)

        interaction.reply({ content: `${emoji.get(`certo`)} | Footer do painel alterado!`, ephemeral: true })

        uppembed()
     }

     if (interaction.customId === "modaltext") {
      const text = interaction.fields.getTextInputValue("text")

      General.set(`systemrestoque.texto_painel`, text)

        interaction.reply({ content: `${emoji.get(`certo`)} | Texto do painel alterado!`, ephemeral: true })

        uppembed()
     }

     if (interaction.customId === "modaldesc") {
      const desc = interaction.fields.getTextInputValue("desc")

      General.set(`systemrestoque.desc_painel`, desc)

        interaction.reply({ content: `${emoji.get(`certo`)} | Descrição do painel alterado!`, ephemeral: true })

        uppembed()
     }

     if (interaction.customId === "modalcolor") {
      const colorInput = interaction.fields.getTextInputValue("color");
      const isValidHexColor = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/.test(colorInput);
    
      if (!isValidHexColor) {
        interaction.reply({ content: `${emoji.get("alerta")} | Isso não é uma cor hexadecimal válida!`, ephemeral: true });
        return;
      }
    
      General.set(`systemrestoque.color`, colorInput);
    
      interaction.reply({ content: `${emoji.get(`certo`)} | Cor do painel alterada!`, ephemeral: true });
    
      uppembed();
    }
     
  });

  }
};

function link(n) {
  const urlRegex = /^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/;
  return urlRegex.test(n)
}

