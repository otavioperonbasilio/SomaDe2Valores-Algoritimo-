const Discord = require("discord.js");
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, ChannelSelectMenuBuilder, RoleSelectMenuBuilder, ChannelType, UserSelectMenuBuilder, StringSelectMenuBuilder } = require("discord.js")
const { perms, General, emoji, produto, tema } = require("../../DataBaseJson")
const fs = require("fs");

module.exports = {
  name: "solicitar_restoque",
  description: "[🛠️|📦] Painel de solicitar restoque",
  type: Discord.ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {
    if (!perms.has(interaction.user.id)) return interaction.reply({
      embeds: [new EmbedBuilder()
        .setDescription(`${emoji.get(`alerta`)} | Você não possui permissão para utilizar este comando!`)
        .setColor("Red")
      ],
      ephemeral: true
    })

    await interaction.reply({ content: `✅ | Painel de solitação de restoque enviado com êxito.`, ephemeral: true })

    const textoView = General.get("systemrestoque.texto_painel");
    const descView = General.get("systemrestoque.desc_painel");
    const miniaturaView = General.get("systemrestoque.miniatura");
    const bannerView = General.get("systemrestoque.banner");
    const footerView = General.get("systemrestoque.footer");
    const colorView = General.get("systemrestoque.color");

    const embed = new EmbedBuilder()
      .setAuthor({ name: interaction.client.user.username, iconURL: interaction.client.user.displayAvatarURL({ dynamic: true }) })
      .setTitle(`${textoView != "" ? textoView : "Texto não definido"}`)
      .setDescription(`${descView != "" ? descView : "Descrição não definida."}`)
      .setColor(colorView != "" ? colorView : "#000000")
      .setFooter({ text: `${footerView != "" ? footerView : `${interaction.guild.name}`}`, iconURL: interaction.guild.iconURL() });

    if (miniaturaView) {
      embed.setThumbnail(miniaturaView);
    }

    if (bannerView) {
      embed.setImage(bannerView);
    }

    const buttons = new Discord.ActionRowBuilder().addComponents(
      new Discord.ButtonBuilder()
        .setCustomId("solicit_estoque")
        .setEmoji(`${emoji.get(`caixa`)}`)
        .setLabel("Solicitar estoque")
        .setStyle(2),
    );

    interaction.channel.send({
      embeds: [embed],
      components: [buttons],
      ephemeral: false,
    });
  }
}