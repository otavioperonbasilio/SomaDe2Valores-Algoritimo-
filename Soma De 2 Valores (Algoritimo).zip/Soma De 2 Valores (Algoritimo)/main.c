#include <stdio.h>
#include <stdlib.h>

 main(){
 int varA , varB , soma;



    printf("Digite valor de A:");
    scanf ("%d" , &varA);
    printf("Digite valor de B:");
    scanf("%d" , &varB);
    soma = varA + varB;
    printf("%d" , soma);

    return 0;
}


// -------------------------------------------------------------------------------------------
// int (declara a variavel por inteiro "varA" "varB" "soma")
// printf (texto que aparece na tela)
// scanf ("%d" fala que � um n�mero, "&" pucha a variavel "varA" "varB" "soma")
// soma = varA + varB; (Efetua a a��o = Efetua a soma)
